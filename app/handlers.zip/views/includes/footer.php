<?php
/**
 * Created by PhpStorm.
 * User: Lukasz
 * Date: 07/11/2016
 * Time: 08:40
 */
use Battleheritage\core\Url ;
?>
</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script src="<?php echo Url::main()?>/vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo Url::path()?>/js/bootstrap-slider.min.js"></script>
<script src="<?php echo Url::path()?>/js/bootstrap-slider.js"></script>
<script src="<?php echo Url::main()?>/vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo Url::main()?>/vendor/metisMenu/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo Url::path()?>/js/sb-admin-2.js"></script>

<script>$('.ex1').slider({
        formatter: function(value) {
            return 'Current value: ' + value;
        }
    });</script>

<script>
    $(document).ready(function(){
        $('.dropdown-submenu a.test').on("click", function(e){
            $(this).next('ul').toggle();
            e.stopPropagation();
            e.preventDefault();
        });
    });
</script>


</body>

</html>
